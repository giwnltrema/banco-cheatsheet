
🔗 DOWNLOAD LINKS FOR FULL DBRE TOOLKIT

# Core Tools
- AWS CLI: https://awscli.amazonaws.com/AWSCLIV2.zip
- MongoDB Atlas CLI: https://downloads.mongodb.com/compass/mongodb-atlas-cli/mongodb-atlas-cli-latest-windows-x86_64.zip
- OCI CLI: https://objectstorage.us-ashburn-1.oraclecloud.com/n/id... (use OCI's install script with --accept-all-defaults)

# Kubernetes Tools
- kubectl: https://dl.k8s.io/release/v1.29.0/bin/windows/amd64/kubectl.exe
- k9s: https://github.com/derailed/k9s/releases/latest/download/k9s_Windows_x86_64.tar.gz

# Cloud Tools
- Terraform: https://releases.hashicorp.com/terraform/1.8.4/terraform_1.8.4_windows_amd64.zip
- jq: https://github.com/stedolan/jq/releases/download/jq-1.6/jq-win64.exe
- curl: https://curl.se/windows/dl-8.7.1_4/curl-8.7.1_4-win64-mingw.zip

# Node.js & AWS Azure Login
- Node.js Portable: https://nodejs.org/dist/v18.19.1/node-v18.19.1-win-x64.zip
- aws-azure-login (run: npm install -g aws-azure-login)

# Python
- Python Embedded: https://www.python.org/ftp/python/3.12.2/python-3.12.2-embed-amd64.zip
- pip bootstrap: https://bootstrap.pypa.io/get-pip.py

# DB Clients
- psql: https://get.enterprisedb.com/postgresql/postgresql-15.4-1-windows-x64-binaries.zip
- mysql: https://dev.mysql.com/get/Downloads/MySQL-8.0/mysql-8.0.36-winx64.zip
- mongosh: https://downloads.mongodb.com/compass/mongosh/mongodb-mongosh-2.2.5-win32-x64.zip
- sqlplus (Oracle): https://download.oracle.com/otn_software/nt/instantclient/instantclient-basiclite-windows.x64-21.13.0.0.0dbru.zip
- sqlcmd (SQL Server): https://aka.ms/sqlcmd-win64

Move all binaries into their respective folders.
